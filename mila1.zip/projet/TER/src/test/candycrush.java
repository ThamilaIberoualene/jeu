package test;
import java.awt.Point;
 
public class candycrush
{
    private static class Bonbon
    {
        int type; // de 1 a 6 (carre,ovale,larme,rond,hexagone,saucisse)
        int niveau; // 1 = normal ; 2 = bonus ; 3 = super bonus
   

    /** Cr�e un bonbon al�atoire */
    public Bonbon(){
      this((int) (Math.random()*6)+1,(int) (Math.random()*3)+1);
    }
    /** Cr�e un bonbon de type et niveau pr�cis�s */
    public Bonbon(int type, int niveau){
      this.type=type;
      this.niveau = niveau;
    }
    public int getType(){ return type; }
    public int getNiveau(){ return niveau; }
 }
    
    static class Partie
    {
        Bonbon[][] jeu;
        int points;
    }
 
    static class Alignement
    {
        Point debut,fin;
    }
 
    static Partie creerpartie (int l, int h) // Creer une nouvelle partie 
    {
        Partie p = new Partie();
        p.jeu = new Bonbon[h][l];
        for (int i=0 ; i<h; i++)
        {
            for(int j=0 ; j<l ; j++)
            {
                p.jeu[i][j] = new Bonbon();
                p.jeu[i][j].type = ((int) (Math.random()*6))+1;
                p.jeu[i][j].niveau = ((int) (Math.random()*3))+1;
 
            }
        }
        return p;
    }
 
    static void affichage (Partie p, InterfaceCC toto, int h, int l) // Affiche les differents types de bonbons dans une fonction
    {
        for (int i=0 ; i<h; i++)
        {
            for(int j=0 ; j<l ; j++)
            {
                if(p.jeu[i][j].type == 1)
                    toto.dessinerCarre(i,j,0);
                if(p.jeu[i][j].type  == 2)
                    toto.dessinerOvale(i,j,0);
                if(p.jeu[i][j].type == 3)
                    toto.dessinerLarme(i,j,0);
                if(p.jeu[i][j].type == 4)
                    toto.dessinerRond(i,j,0);
                if(p.jeu[i][j].type == 6)
                    toto.dessinerHexagone(i,j,0);
                if(p.jeu[i][j].type == 6)
                    toto.dessinerSaucisse(i,j,0);
             }
        }
    }
 
    static Alignement Alignement1 (Partie p) // Fonction qui detecte les alignements en cours de partie
    {
        int k;
        for (int i=0 ; i<p.jeu.length; i++)
        {
            for(int j=0 ; j<p.jeu[i].length; j++)
            {
                k=1;
 
                while(i+k<p.jeu.length && p.jeu[i][j].type == p.jeu[i+k][j].type) // Tant que la case qui suit i est du meme type on continue (alignement horizontale)
                {
                    k = k+1; //
                }
 
                if(k>2) // Si k est superieur a  2 alors il y a un alignement
                {
                    Alignement a = new Alignement();
                    a.debut = new Point();
                    a.debut.x = i;
                    a.debut.y = j;
                    a.fin = new Point();
                    a.fin.x = i+k-1;
                    a.fin.y = j;
                    return a;                
                }
 
                k=1;
                while(j+k<p.jeu[i].length && p.jeu[i][j].type == p.jeu[i][j+k].type)
                {
                    k = k+1;
                }
 
                if(k>2)
                {
                    Alignement a = new Alignement();
                    a.debut = new Point();
                    a.debut.x = i;
                    a.debut.y = j;
                    a.fin = new Point();
                    a.fin.x = i;
                    a.fin.y = j+k-1;
                    return a;
                }
 
            }
        }
        return null;
    }
    static void DecalerBonbon (Partie p, Alignement a)
    {
        if(a.debut.y == a.fin.y) //Alignement horizontal
        {
            for(int i = a.debut.x ; i<= a.fin.x ; i++)
            {
                for(int j = a.debut.y ; j>=1 ; j--)
                {
 
                    p.jeu[i][j] = p.jeu[i][j-1];
 
 
                }
                p.jeu[i][0] = new Bonbon(); // et un nouveau bonbon al�atoire dans la case de t�te
            }
        }
        if(a.debut.x == a.fin.x) // Alignement vertical
        {
 
            for(int j = 0 ; a.fin.y-j >= 0 ; j++)
            {
                if(a.debut.y-1-j >= 0)
                {
                    p.jeu[a.debut.x][a.fin.y-j] = p.jeu[a.debut.x][a.debut.y-1-j];
                }
                else
                {
                	p.jeu[a.debut.x][a.fin.y-j] = new Bonbon(); // et un nouveau bonbon al�atoire dans la case de t�te
                }
            }
        }
 
    }
 
    public static void main(String[] args)
    {
        int l,h,min,max,temporaire;
        Point p1 = new Point();
        Point p2 = new Point();
        l = 8;
        h = 8;
        min = 1;
        max = 6;
        InterfaceCC toto = new InterfaceCC(h,l);
 
        Partie p = creerpartie(8,8);
 
        while (true) // On peut cliquer jusqu'a  ce qu'il n'est plus de combinaison possible
        {
            affichage(p,toto,h,l);
            p1 = toto.clicCase();    //Nouveau point afin d'inverser 2 bonbons
            System.out.println(p1.x + " " + p1.y); //Garde en memoire le p1
            p2 = toto.clicCase();
            System.out.println(p2.x + " " + p2.y);
            //inverse 2 points
            if((p1.x==p2.x && Math.abs(p1.y-p2.y)==1) || (p1.y==p2.y && Math.abs(p1.x-p2.x)==1)) //
            { 
                temporaire = p.jeu[p1.x][p1.y].type; 
                p.jeu[p1.x][p1.y].type = p.jeu[p2.x][p2.y].type;
                p.jeu[p2.x][p2.y].type = temporaire;
                affichage(p,toto,h,l);
                Alignement a = Alignement1(p);
                System.out.println(a.debut.x+","+a.debut.y+"   ->    "+a.fin.x+","+a.fin.y);
 
                DecalerBonbon(p,a);
            }
        }
    }
}