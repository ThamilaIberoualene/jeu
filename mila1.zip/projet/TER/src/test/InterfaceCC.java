package test;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import static javax.swing.SwingConstants.*;
 
public class InterfaceCC extends JFrame implements MouseListener{
 
    private interface GraphicEntity{
        public void paint(Graphics2D g, Point p, int cell, int border);
    }
 
    private class Carre implements GraphicEntity{
        Color c = Color.GREEN; int niveau;
        public Carre(int niveau){this.niveau = niveau;}
        public void paint(Graphics2D g, Point p, int cell, int border){
            if(niveau==3) g.setColor(Color.WHITE);
            else g.setColor(this.c);
            float coeff = 8.0f;
            GeneralPath tour = new GeneralPath();
            tour.moveTo((p.x+1)*cell-border,p.y*cell+border); 
            tour.curveTo((p.x+1)*cell-border,p.y*cell+border,(p.x+1)*cell-border-cell/coeff,p.y*cell+cell/2.0f,(p.x+1)*cell-border,(p.y+1)*cell-border);
            tour.lineTo(p.x*cell+border,(p.y+1)*cell-border);
            tour.curveTo(p.x*cell+border,(p.y+1)*cell-border,p.x*cell+border+cell/coeff,p.y*cell+cell/2.0f,p.x*cell+border,p.y*cell+border);
            tour.closePath();
            if(this.niveau == 1){
                Point2D start = new Point2D.Float(0, 0);
                Point2D end = new Point2D.Float(0, cell/rayures);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE};
                LinearGradientPaint pai = new LinearGradientPaint(start, end, dist, colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            } 
            if(this.niveau == 2){
                Point2D center = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float radius = cell/cercles;
                Point2D focus = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE,};
                RadialGradientPaint pai = new RadialGradientPaint(center,radius,focus,dist,colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }  
            g.fill(tour);
        }
    }
 
    private class Ovale implements GraphicEntity{
        Color c = Color.ORANGE; int niveau;
        public Ovale(int niveau){this.niveau = niveau;}
        public void paint(Graphics2D g, Point p, int cell, int border){
            if(niveau==3) g.setColor(Color.WHITE);
            else g.setColor(this.c);
            float coeff = 6.0f;
            if(this.niveau == 1){
                Point2D start = new Point2D.Float(0, 0);
                Point2D end = new Point2D.Float(0, cell/rayures);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE};
                LinearGradientPaint pai = new LinearGradientPaint(start, end, dist, colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            if(this.niveau == 2){
                Point2D center = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float radius = cell/cercles;
                Point2D focus = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE,};
                RadialGradientPaint pai = new RadialGradientPaint(center,radius,focus,dist,colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            g.fillOval((int) (p.x*cell+border+cell/(2*coeff)),p.y*cell+border,(int) (cell-2*border-cell/coeff),cell-2*border);
        }
    }
 
    private class Larme implements GraphicEntity{
        Color c = Color.YELLOW; int niveau;
        public Larme(int niveau){this.niveau = niveau;}
        public void paint(Graphics2D g, Point p, int cell, int border){
            if(niveau==3) g.setColor(Color.WHITE);
            else g.setColor(this.c);
            float coeff = 4.0f/5;
            GeneralPath tour = new GeneralPath();
            tour.moveTo(p.x*cell+cell/2.0f,p.y*cell+border);
            tour.lineTo((p.x+1)*cell-border,p.y*cell+border+(cell-2*border)*coeff);
            tour.curveTo((p.x+1)*cell-border,p.y*cell+border+(cell-2*border)*coeff, p.x*cell+cell/2.0f,(p.y+1)*cell,p.x*cell+border,p.y*cell+border+(cell-2*border)*coeff);
            tour.closePath();
            if(this.niveau == 1){
                Point2D start = new Point2D.Float(0, 0);
                Point2D end = new Point2D.Float(0, cell/rayures);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE};
                LinearGradientPaint pai = new LinearGradientPaint(start, end, dist, colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            if(this.niveau == 2){
                Point2D center = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float radius = cell/cercles;
                Point2D focus = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE,};
                RadialGradientPaint pai = new RadialGradientPaint(center,radius,focus,dist,colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            g.fill(tour);
        }
    }
 
    private class Rond implements GraphicEntity{
        Color c = Color.BLUE; int niveau;
        public Rond(int niveau){this.niveau = niveau;}
        public void paint(Graphics2D g, Point p, int cell, int border){
            if(niveau==3) g.setColor(Color.WHITE);
            else g.setColor(this.c);
            if(this.niveau == 1){
                Point2D start = new Point2D.Float(0, 0);
                Point2D end = new Point2D.Float(0, cell/rayures);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE};
                LinearGradientPaint pai = new LinearGradientPaint(start, end, dist, colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            if(this.niveau == 2){
                Point2D center = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float radius = cell/cercles;
                Point2D focus = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE,};
                RadialGradientPaint pai = new RadialGradientPaint(center,radius,focus,dist,colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            g.fillOval(p.x*cell+border,p.y*cell+border,cell-2*border,cell-2*border);
        }
    }
 
    private class Hexagone implements GraphicEntity{
        Color c = new Color(121, 28, 248); int niveau;
        public Hexagone(int niveau){this.niveau = niveau;}
        public void paint(Graphics2D g, Point p, int cell, int border){
            if(niveau==3) g.setColor(Color.WHITE);
            else g.setColor(this.c);
            double d = (cell-2*border)/3.0d;
            GeneralPath tour = new GeneralPath();
            tour.moveTo(p.x*cell+border+d,p.y*cell+border);
            tour.lineTo((p.x+1)*cell-border-d,p.y*cell+border);
            tour.lineTo((p.x+1)*cell-border,p.y*cell+border+d);
            tour.lineTo((p.x+1)*cell-border,(p.y+1)*cell-border-d);
            tour.lineTo((p.x+1)*cell-border-d,(p.y+1)*cell-border);
            tour.lineTo(p.x*cell+border+d,(p.y+1)*cell-border);
            tour.lineTo(p.x*cell+border,(p.y+1)*cell-border-d);
            tour.lineTo(p.x*cell+border,p.y*cell+border+d);
            tour.closePath();
            if(this.niveau == 1){
                Point2D start = new Point2D.Float(0, 0);
                Point2D end = new Point2D.Float(0, cell/rayures);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE};
                LinearGradientPaint pai = new LinearGradientPaint(start, end, dist, colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            if(this.niveau == 2){
                Point2D center = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float radius = cell/cercles;
                Point2D focus = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE,};
                RadialGradientPaint pai = new RadialGradientPaint(center,radius,focus,dist,colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            g.fill(tour);
        }
    }
 
    private class Saucisse implements GraphicEntity{
        Color c = Color.RED; int niveau;
        public Saucisse(int niveau){this.niveau = niveau;}
        public void paint(Graphics2D g, Point p, int cell, int border){
            if(niveau==3) g.setColor(Color.WHITE);
            else g.setColor(this.c);
            double d = (cell-2*border)/3.0d;
            GeneralPath tour = new GeneralPath();
            tour.moveTo(p.x*cell+border+d,p.y*cell+border);
            tour.curveTo(p.x*cell+border+d,p.y*cell+border,p.x*cell+cell/2.0f,p.y*cell+cell/2.0f,(p.x+1)*cell-border,(p.y+1)*cell-border-d);
            tour.curveTo((p.x+1)*cell-border,(p.y+1)*cell-border-d,(p.x+1)*cell-border,(p.y+1)*cell-border,(p.x+1)*cell-border-d,(p.y+1)*cell-border);
            tour.curveTo((p.x+1)*cell-border-d,(p.y+1)*cell-border,p.x*cell+border+(cell-2*border)/2.0f-d,p.y*cell+border+d+(cell-2*border)/2.0f,p.x*cell+border,p.y*cell+border+d);
            tour.curveTo(p.x*cell+border,p.y*cell+border+d,p.x*cell+border,p.y*cell+border,p.x*cell+border+d,p.y*cell+border);
            if(this.niveau == 1){
                Point2D start = new Point2D.Float(0,0);
                Point2D end = new Point2D.Float(0, cell/rayures);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE};
                LinearGradientPaint pai = new LinearGradientPaint(start, end, dist, colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            if(this.niveau == 2){
                Point2D center = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float radius = cell/cercles;
                Point2D focus = new Point2D.Float(p.x*cell+cell/2.0f,p.y*cell+cell/2.0f);
                float[] dist = {0.45f, 0.5f};
                Color[] colors = {c, Color.WHITE,};
                RadialGradientPaint pai = new RadialGradientPaint(center,radius,focus,dist,colors, MultipleGradientPaint.CycleMethod.REPEAT);
                g.setPaint(pai);
            }
            g.fill(tour);
        }
    }
 
    private GraphicEntity[][] grid; 
    private Graphic p;
    private int border = 8, cell = 75, rayures = 4, cercles = 6;
    private KeyEvent ke;
    private MouseEvent clic;
    private JTextField jtf;
 
    private class KEDispatcher implements KeyEventDispatcher {
        public boolean dispatchKeyEvent(KeyEvent e) {
            if (e.getID() == KeyEvent.KEY_PRESSED) {
                if(e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_PAUSE) ke = e;
              }
              return false;
         }
    }
 
    /** @deprecated */
    public void mouseClicked(MouseEvent e){
        this.setClic(e);
        synchronized(this){
            this.notify();
        }
    }
 
    /** @deprecated */
    public void mouseEntered(MouseEvent e){}
 
    /** @deprecated */
    public void mouseExited(MouseEvent e){}
 
    /** @deprecated */
    public void mousePressed(MouseEvent e){}
 
    /** @deprecated */
    public void mouseReleased(MouseEvent e){}
 
    /** @deprecated */
    public void setClic(MouseEvent e){
        this.clic = e;
    }
 
    /** Retourne un Point lorsque l'utilisateur clique sur une case. */
    public synchronized Point clicCase(){
        try{
            this.wait();
        }
        catch(InterruptedException e){}
        ((JComponent) this.clic.getSource()).transferFocusUpCycle();
        return new Point(this.clic.getX()/this.cell,this.clic.getY()/this.cell);
    }
 
    public InterfaceCC(int largeur, int hauteur){
        super("CC");
        this.grid = new GraphicEntity[largeur][hauteur];
        for(int i=0;i<grid.length;i++){
            for(int j=0;j<grid[i].length;j++){
                this.grid[i][j] = null;
            }        
        }
        this.p = new Graphic();
        this.p.setPreferredSize(new Dimension(largeur*this.cell, hauteur*this.cell));
        this.p.addMouseListener(this);
        this.getContentPane().setLayout(new BorderLayout());
        this.getContentPane().add(this.p,BorderLayout.CENTER);
        //this.getContentPane().add(this.p);
        this.jtf = new JTextField(20);
        this.getContentPane().add(this.jtf,BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);
        this.pack();
        KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        manager.addKeyEventDispatcher(new KEDispatcher());
    }
 
    /* Renvoie un entier correspondant � la touche appuyee. CENTER:pause, EAST:fleche droite, WEST:fleche gauche, SOUTH:fleche bas, NORTH:fleche haut
    Renvoie -1 si la touche appuyee n'est ni une fleche ni pause. */
    public int toucheAppuyee(){
        if(this.ke == null) return -1;
        else{
            int result = -1;
            if(this.ke.getKeyCode() == KeyEvent.VK_RIGHT) result = EAST;
            if(this.ke.getKeyCode() == KeyEvent.VK_LEFT) result = WEST;
            if(this.ke.getKeyCode() == KeyEvent.VK_DOWN) result = SOUTH;
            if(this.ke.getKeyCode() == KeyEvent.VK_UP) result = NORTH;
            if(this.ke.getKeyCode() == KeyEvent.VK_PAUSE) result = CENTER;
            this.ke = null;
            return result;
        }
    }
 
    /* Efface la case d'abscisse x et d'ordonnee y */
    public void effaceCase(int x, int y){
        this.grid[x][y] = null;
        this.miseAJour();
    }
 
    public void dessinerCarre(int x, int y, int niveau){
        this.grid[x][y] = new Carre(niveau);
        this.miseAJour();
    }
 
    public void dessinerOvale(int x, int y, int niveau){
        this.grid[x][y] = new Ovale(niveau);
        this.miseAJour();
    }
 
    public void dessinerLarme(int x, int y, int niveau){
        this.grid[x][y] = new Larme(niveau);
        this.miseAJour();
    }
 
    public void dessinerRond(int x, int y, int niveau){
        this.grid[x][y] = new Rond(niveau);
        this.miseAJour();
    }
 
    public void dessinerHexagone(int x, int y, int niveau){
        this.grid[x][y] = new Hexagone(niveau);
        this.miseAJour();
    }
 
    public void dessinerSaucisse(int x, int y, int niveau){
        this.grid[x][y] = new Saucisse(niveau);
        this.miseAJour();
    }
 
    public void miseAJour(){
        this.p.repaint();
    }
 
    private class Graphic extends JPanel{
        public void paint(Graphics gr){
            Graphics2D gr2D = (Graphics2D) gr;
            gr2D.setColor(Color.BLACK);
            gr2D.fillRect(0,0,this.getWidth(),this.getHeight());
            gr2D.setStroke(new BasicStroke(2.0f));
            //int offset = 2;
            for(int i=0;i<grid.length;i++){
                for(int j=0;j<grid[i].length;j++){
                    if(grid[i][j] != null) grid[i][j].paint(gr2D, new Point(i,j), cell, border);
                }
            }
        }
    }
 
    public void afficheMessage(String m){
        JOptionPane.showMessageDialog(this,m);
    }
 
    public void afficheTexte(String t){
        this.jtf.setText(t);
    }
}

