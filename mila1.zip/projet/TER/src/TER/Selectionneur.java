package TER;
import java.awt.Point;
import java.awt.event.*;

public class Selectionneur {
	
	///******Attributs*****************
	private Point premier;
	private Point deuxieme;
	private Plateau plateau;
	
	
	
	///******Constructeur*****************
	
	public Selectionneur(Plateau p) {
		this.plateau = p;
		suppSelection();
	}

	///****************M�thode**********
	public void selection(Point p) {
		if (this.premier == null) {
			this.premier = p;
		}
		else {
			deuxieme = p;
		}
		if(voisin(premier, deuxieme)) {
			plateau.permutation(premier, deuxieme);
			if(!plateau.correspond()) {
				plateau.permutation(premier, deuxieme);
			}
			plateau.echangeContenu();
		}
		suppSelection();
	}
	
	
	public Point selectionPremier() {
		return this.premier;
	}
	
	public boolean voisin(Point p, Point v) {
		return Math.abs(p.x-v.x) + Math.abs(p.y - v.y) == 1; 
	}
	
	private void suppSelection() {
		premier = null;
		deuxieme = null;
	}
	
}
