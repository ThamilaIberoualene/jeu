package TER;

import java.awt.Point;
import java.util.*;

public class Plateau {
	
	private ArrayList<ArrayList<String>> plateau;
	private ArrayList<String> nomCouleur;
	private Random aleatoire;
	private int compteur;
	
	private static int MAX_COULEURS = 3;
	
	public Plateau(int lignes, int colonnes) {
		do {
			compteur = 0;
			plateau = new ArrayList<ArrayList<String>>();
			aleatoire = new Random();
			
			for (int i = 0; i < MAX_COULEURS; i++ ) {
				nomCouleur.add("Image/"+i+".png");
			}
			for(int l = 0;  l < lignes; l++) {
				ArrayList<String> ligne = new ArrayList<String>();
				for (int c = 0; c < colonnes; c++) {
				ligne.add(nomCouleur.get(aleatoire.nextInt(nomCouleur.size())));
				}
				plateau.add(ligne);
			}
		}while(verifCorrespondance()== true && deplacementPermis(plateau)==true);
	}
	
	public int lignes() {
		return plateau.size();	
		}
	
	public int colonnes() {
		return plateau.get(0).size();
	}
	
	public String getPosition(Point p) {
		return plateau.get(p.x).get(p.y);
	}
	
	public String setPosition(Point p, String s) {
		return plateau.get(p.x).set(p.y, s);
	}
	
	public void permutation(Point p, Point v) {
		String point = this.getPosition(p);
		this.setPosition(p, this.getPosition(p));
		this.setPosition(v, point);
		if(correspond().size()>0) {//////**************************
			plateau.supprimer(p);
			plateau.supprimer(point);/////////************
		}
	}
	
	public void echangeContenu() {
		if(correspond().size()>0) {
			while(verifCorrespondance() == true) {
				System.out.println("Les deux points se correspondent");
			}
		}
	}
	
	public boolean verifCorrespondance() {
		if(correspond().size()>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public LinkedHashSet<Point> correspond(){
		return correspond();////////////************
	}
	
	public void suppContenu() {
		for(Point p : correspond()) {
			Point p1 = new Point(p.x, p.y);
			Point p2 = new Point();
			this.setPosition(p, null);
			while(p1.x != 0) {
				p2.setLocation(p1.x-1, p1.y);
				String point = this.getPosition(p1);
				this.setPosition(p1,  this.getPosition(p2));
				this.setPosition(p2, point);
				p1 = new Point(p1.x - 1 , p1.y);
			}
			this.setPosition(p1, nomCouleur.get(aleatoire.nextInt(nomCouleur.size())));
		}
	}
	
	public void decalageBas(Point p) {
		this.setPosition(p, nomCouleur.get(aleatoire.nextInt(nomCouleur.size())));
	}
	/*****************************////////////////***********/
	
}
