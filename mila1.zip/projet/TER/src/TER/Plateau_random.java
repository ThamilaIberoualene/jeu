package TER;

import java.util.Random;
import java.util.Scanner;

public class Plateau_random{
	
	
	public enum Couleur {R,V,B,J}
	
	// attributs 
	private int colonnes;
	private int lignes;
	// d�finir un tableau multidimensioennel de type caract�res
	
	private Couleur[][] plateau;
	
	// constructeur 
	public Plateau_random(int lignes, int colonnes) {
		
		this.lignes = lignes;
		this.colonnes = colonnes;
		
		// on cr�e un nouveau plateau 
		this.plateau = new Couleur [lignes][colonnes];
		
		// boucle for qui permettra de cr�er toutes les lignes et colonnes
		for(int i=0; i<lignes; i++) {
			for(int j=0; j<colonnes; j++) {
				// notre coordonn�e x et y aura pour contenu 
				plateau[i][j] = Couleur.values()[new Random().nextInt(Couleur.values().length)];
				
			}
		}
	}
	
	
	public void afficher() {
		// boucle for pour afficher lignes et colonnes
		for(int i=0; i<lignes; i++) {
			if(i>=10) {
				System.out.print(i+" ");
			}else
			System.out.print(i+"  ");
			
			for(int j=0; j<colonnes; j++) {
				System.out.print(" | " + plateau[i][j]);
			}
			System.out.println(" |");
		}
		System.out.println();
		System.out.print("      0"+"   1"+"   2"+"   3"+"   4"+"   5"+"   6"+"   7"+"   8"+"   9"+"   10"+"  11");
		System.out.println("\n");
	}
	
	
	/*public void placer(int colonnes, int lignes, char t) {
		// pour plus de compr�hension nous allons commencer par un d'ou -1 pour retrouver le 0 initiale
		colonnes = colonnes - 1; 
		lignes = lignes -1;
		
		// tester si la position que nous allons indiquer est bien inf�rieur au nombre de lignes et colonnes
		if(colonnes < 0 || lignes < 0 || lignes > lignes || colonnes > colonnes) {
			System.out.println("Erreur : position non trouv�");
			// retourne la position erron� 
			return;
		}else if(plateau[lignes][colonnes] == '.') {
			// si la position est correcte
			// on affecte la position au nouvel �l�ment
			plateau[lignes][colonnes] = t;
		}else {
			System.out.println("Erreur : la position d�passe les coordonn�es du plateau");
		}
	}
	
	*/
	
	public void permuter(int lignes, int colonnes, int choix) {
		
		Couleur stockContenuEchange = plateau[lignes][colonnes];
		
		if(choix==6) {
			plateau[lignes][colonnes] = plateau[lignes][colonnes+1];
			plateau[lignes][colonnes+1] = stockContenuEchange;
			
			//alignement (sur la droite)
			if(plateau[lignes][colonnes+1] == plateau[lignes][colonnes+2] & plateau[lignes][colonnes+2] == plateau[lignes][colonnes+3]
					& plateau[lignes][colonnes+3] == plateau[lignes][colonnes+4]) {
				System.out.println("alignement de 4 horizontal");	
			} 
				
			if(plateau[lignes][colonnes+1] == plateau[lignes][colonnes+2] & plateau[lignes][colonnes+2] == plateau[lignes][colonnes+3]) {
				System.out.println("alignement de 3 horizontal");							
			}
						
			//alignement (sur le bas)
			if(plateau[lignes][colonnes+1] == plateau[lignes+1][colonnes+1] & plateau[lignes+1][colonnes+1] == plateau[lignes+2][colonnes+1]
					& plateau[lignes+2][colonnes+1] == plateau[lignes+3][colonnes+1]) {
				System.out.println("alignement de 4 vertical");	
			} 
				
			if(plateau[lignes][colonnes+1] == plateau[lignes+1][colonnes+1] & plateau[lignes+1][colonnes+1] == plateau[lignes+2][colonnes+1]) {
				System.out.println("alignement de 3 vertical");							
			}
			
			//alignement (sur le haut)
			if(plateau[lignes][colonnes+1] == plateau[lignes-1][colonnes+1] & plateau[lignes-1][colonnes+1] == plateau[lignes-2][colonnes+1]
					& plateau[lignes-2][colonnes+1] == plateau[lignes-3][colonnes+1]) {
				System.out.println("alignement de 4 vertical");	
			} 
				
			if(plateau[lignes][colonnes+1] == plateau[lignes-1][colonnes+1] & plateau[lignes-1][colonnes+1] == plateau[lignes-2][colonnes+1]) {
				System.out.println("alignement de 3 vertical");							
			}
			
		}
		
		
		if(choix==4) {
			plateau[lignes][colonnes] = plateau[lignes][colonnes-1];
			plateau[lignes][colonnes-1] = stockContenuEchange;
		}
		
		if(choix==8) {
			plateau[lignes][colonnes] = plateau[lignes-1][colonnes];
			plateau[lignes-1][colonnes] = stockContenuEchange;
		}
		
		if(choix==2) {
			plateau[lignes][colonnes] = plateau[lignes+1][colonnes];
			plateau[lignes+1][colonnes] = stockContenuEchange;
		}	
	}
	

		
	
	public static void main(String[]args) {
		// instancier un objet de plateau
		Plateau_random p = new Plateau_random(12,12);
		//p.placer(4, 4, 'b');
		p.afficher();
		
		Scanner sc = new Scanner(System.in);
		
		int l, c, direction;
		
		System.out.println("ligne ?");
		l = sc.nextInt();
		System.out.println("colonne ?");
		c = sc.nextInt();
		System.out.println("direction ?");
		direction = sc.nextInt();
		p.permuter(l,c,direction);
		p.afficher();
		
			
	}
}