package TER;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;

import TER.Plateau_random.Couleur;

public class Panneau {
	
	// attributs 
	private ArrayList<ArrayList<String>> _plateau;
	private ArrayList<String> _nomCouleur;
	JFrame fenetre; //D�finition de la fen�tre du jeu 
	JLabel Case[][];//D�finition du Case du plateau
	// définir un tableau multidimensioennel de type caractères
	int contenu[][];//cr�ation de la contenu contenu
 	Random aleatoire;//D�finition de la m�thode Random
	//pour g�n�r� les billes al�atoirement
 	private int _score;
	private static int MAX_COLORS = 6;	
 	
 	// constructeur  
	public Panneau() {
		fenetre = new JFrame("Jeu Evolutif");//Cr�ation de la fen�tre du Jeu �volutif 
		fenetre.setBounds(0, 0, 700, 650);//D�finition des dimention de la fenetre
		fenetre.setLayout(null);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//D�finition du lancement de la fenetre
		
		Case = new JLabel[12][12];//D�finition des dimension de la case 
		contenu = new int[12][12];//D�finition des dimension de la case
		aleatoire = new Random();///initialisation de la fonction al�atoire
		for (int i=0; i<Case.length; i++) {
			for(int j = 0; j < Case.length; j++) {
				Case[i][j] = new JLabel();//cr�ation de la Case
				Case[i][j].setBounds(i*45,j*50,50,50);//d�finition de la taille et l'espacement
				//entre Case
				contenu[i][j] = aleatoire.nextInt(5)+1;//G�n�ration des bille (6 bille) une par une
				Case[i][j].setIcon(new ImageIcon("images/"+contenu[i][j]+".png"));//Remplir les case avec du contenu
				//D�finir la fonction nbCouleur()***********************
				Case[i][j].setVisible(true);//
				fenetre.add(Case[i][j]);
				////
			}
		}
		/////Teste Pour fix� les pierres en haut du plateau//////
		Case[5][0].setIcon(new ImageIcon("images/"+6+".png"));
		fenetre.add(Case[5][0]);
		Case[7][0].setIcon(new ImageIcon("images/"+6+".png"));
		fenetre.add(Case[7][0]);
		Case[0][0].setIcon(new ImageIcon("images/"+6+".png"));
		fenetre.add(Case[0][0]);
		////////////////////////////////////////////////////////
		
		
		for (int i=0; i<Case.length; i++) {
			for(int j = 0; j < Case.length; j++) {
				Case[i][j].addMouseListener(new MouseAdapter() {//Ecouteur d'�venement pour glisser (permutation)
					public void mouseClicked(MouseEvent ev) { 
						//Fonction pour pointer sur une case 
						for (int k = 0; k<Case.length; k++) {
							for (int l = 0; l<Case.length; l++) {
								if( Case[k][l] == ev.getSource()) {
									System.out.println("position: "+k+" "+l);
									
									selection(k, l, contenu[k][l]);//Pass� les param�tre d'entree � la fonction selection
								}
							}
						}			
						//Fonction �limin� (Manque m�thode alignement)
						for(int m=0; m<Case.length;m++) {
							for (int k = 0; k<Case.length; k++) {
								for (int l = 0; l<Case.length; l++) {
									if(l>0 && contenu[k][l] == -2) {///********************essay� de vid� la case pour appliqu� la m�thode RemplaceVide()
										contenu[k][l] = contenu[k][l-1];
										Case[k][l].setIcon(new ImageIcon("images/"+contenu[k][l]+".png"));
										contenu[k][l-1] = -2; 
										//contenu[k][0] = aleatoire.nextInt(5)+1;//G�n�ration des bille (6 bille) une par une
									}
									Case[k][l].setIcon(new ImageIcon("images/"+contenu[k][l]+".png"));
								}
							}//////////////***************Ajouter des billes apr�s �limination**********/////////
						}
					}
				});
			}
		
		}
	
		fenetre.setVisible(true);
	}
	
	public void selection(int px, int py, int couleur) {
		if(couleur!=-1) {
			contenu[px][py] = -1;
		}
		if(couleur==-1) {
			contenu[px][py] = -2;
		}
		Case[px][py].setIcon(new ImageIcon("images/"+contenu[px][py]+".png"));
		
		if(px < 11 && contenu[px+1][py] == couleur) {
			selection(px+1, py, couleur);
		}
		if(px > 0 && contenu[px-1][py] == couleur) {
			selection(px-1, py, couleur);
		}
		if(py < 11 && contenu[px][py+1] == couleur) {
			selection(px, py+1, couleur);
		}
		if(py > 0 && contenu[px][py-1] == couleur) {
			selection(px, py-1, couleur);
		}
		
	}

	public static void main(String[] args) {
		Panneau panneau = new Panneau();
	}

}
