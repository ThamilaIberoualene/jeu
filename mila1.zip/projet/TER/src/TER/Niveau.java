package TER;

public class Niveau extends Plateau{
	
	///******Attributs*****************
	private int NumNiveau;
	private int NbCoup=20;
	private int NbCouleur=3;
	private int NbBille=3;
	private boolean DebutN=false;
	private boolean FinN=false;
	private Panneau plateau;
	


	///******Constructeur*****************
	public Niveau() {
		this.plateau = new Panneau();
	}
	
	public Niveau(int NumNiveau, int nbCoup, int nbCouleur, int nbBille, boolean debutN, boolean finN) {
		this.setNumNiveau(NumNiveau);
		this.setNbCoup(nbCoup);
		this.setNbCouleur(nbCouleur);
		this.setNbBille(nbBille);
		this.setDebutN(debutN);
		this.setFinN(finN);
		this.plateau = new Panneau();	
		}
	
	
	
	///******Accesseurs*****************
	public int getNumNiveau() {
		return NumNiveau;
	}
	public void setNumNiveau(int NumNiveau) {
		this.NumNiveau=NumNiveau;
	}
	

	public int getNbCoup() {
		return NbCoup;
	}
	public void setNbCoup(int nbCoup) {
		this.NbCoup = nbCoup;
	}
	
	
	public int getNbCouleur() {
		return NbCouleur;
	}
	public void setNbCouleur(int nbCouleur) {
		this.NbCouleur = nbCouleur;
	}
	
	
	public int getNbBille() {
		return NbBille;
	}
	public void setNbBille(int nbBille) {
		this.NbBille = nbBille;
	}
	
	
	public boolean isDebutN() {
		return DebutN;
	}
	public void setDebutN(boolean debutN) {
		this.DebutN = debutN;
	}
	
	
	public boolean isFinN() {
		return FinN;
	}
	public void setFinN(boolean finN) {
		this.FinN = finN;
	}
	
	
	public Panneau getPlateau() {
		return plateau;
	}

	public void setPlateau(Panneau plateau) {
		this.plateau = plateau;
	}
	
}
