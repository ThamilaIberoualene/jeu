package TER;



import java.applet.*;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("deprecation")
public class AppletMotion extends Applet implements MouseMotionListener{
   private int x;
   private int y;

   public void init() { 
      super.init();
      this.addMouseMotionListener(this);
   }

   public void mouseDragged(java.awt.event.MouseEvent e) {}

   public void mouseMoved(MouseEvent e) {
      x = e.getX();
      y = e.getY();
      repaint();
      showStatus("x = "+x+" ; y = "+y);
   }

   public void paint(Graphics g) {
      super.paint(g);
      g.drawString("x = "+x+" ; y = "+y,20,20);
   }
}