package test2;
try {
    BufferedImage img=ImageIO.read(new File("c:/image.png"));
 
    // parcourir les pixels de l'image
for (int i = 0; i < img.getWidth(); i++) {
    for (int j = 0; j < img.getHeight(); j++) {
     
    // recuperer couleur de chaque pixel
    Color pixelcolor= new Color(img.getRGB(i, j));
     
    // recuperer les valeur rgb (rouge ,vert ,bleu) de cette couleur
    int r=pixelcolor.getRed();
    int g=pixelcolor.getGreen();
    int b=pixelcolor.getBlue();
     
    // faire l'inversion
    r=Math.abs(r-255);
    g=Math.abs(g-255);
    b=Math.abs(b-255);
         
     
    int rgb=new Color(r,g,b).getRGB();
     
    // changer la couleur de pixel avec la nouvelle couleur invers�e
    img.setRGB(i, j, rgb);

    }
}
    // enregistrement d'image
    ImageIO.write(img, "png",new File("c:/inverse.png"));
     
} catch (Exception e) {
    System.err.println("erreur -> "+e.getMessage());
}
 